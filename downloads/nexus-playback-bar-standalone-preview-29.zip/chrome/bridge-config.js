// Install-NEXUS.cmd replaces this file with the pairing configuration.
globalThis.NEXUS_BRIDGE_KEY = "";
